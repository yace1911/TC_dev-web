<?php
class Model {
    protected $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function query($sql, $params = []) {
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function findAll($table) {
        $sql = "SELECT * FROM $table";
        return $this->query($sql)->fetchAll(PDO::FETCH_OBJ);
    }

    public function findById($table, $id) {
        $sql = "SELECT * FROM $table WHERE id = ?";
        return $this->query($sql, [$id])->fetch(PDO::FETCH_OBJ);
    }

    public function delete($table, $id) {
        $sql = "DELETE FROM $table WHERE id = ?";
        return $this->query($sql, [$id]);
    }
} 