<?php
class Controller {
    public function model($model) {
        require_once '../app/models/' . $model . '.php';
        return new $model();
    }

    public function view($view, $data = []) {
        if (is_array($data)) {
            extract($data);
        }
        require_once '../app/views/' . $view . '.php';
    }

    public function redirect($url) {
        header('Location: /MY-boutique/public/' . $url);
        exit;
    }

    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    public function isAdmin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }

    public function isIT() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'it';
    }
} 