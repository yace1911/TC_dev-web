<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panier - MY Boutique</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/MY-boutique/public/assets/css/style.css">
</head>
<body>
    <!-- En-tête -->
    <?php require_once '../app/views/partials/header.php'; ?>
    
    <div class="container mt-4">
        <h1>Mon Panier</h1>
        
        <!-- Messages de succès/erreur -->
        <?php if(isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php 
                echo $_SESSION['success_message']; 
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?php 
                echo $_SESSION['error_message']; 
                unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>
        
        <?php if(empty($cartItems)): ?>
            <div class="alert alert-info">
                Votre panier est vide. <a href="/MY-boutique/public/product" class="alert-link">Continuez vos achats</a>.
            </div>
        <?php else: ?>
            <form action="/MY-boutique/public/order/updateCart" method="POST">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Produit</th>
                                <th>Prix</th>
                                <th>Quantité</th>
                                <th>Total</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($cartItems as $item): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo $item['product']->image; ?>" alt="<?php echo $item['product']->nom; ?>" class="img-thumbnail me-2" style="max-width: 80px;">
                                            <div>
                                                <h5><?php echo $item['product']->nom; ?></h5>
                                                <small class="text-muted"><?php echo $item['product']->categorie; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo number_format($item['product']->prix, 2, ',', ' '); ?> €</td>
                                    <td>
                                        <div class="input-group" style="max-width: 120px;">
                                            <button type="button" class="btn btn-outline-secondary quantity-btn" data-action="decrease">-</button>
                                            <input type="number" name="cart[<?php echo $item['product']->id; ?>]" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['product']->stock; ?>" class="form-control text-center quantity-input">
                                            <button type="button" class="btn btn-outline-secondary quantity-btn" data-action="increase">+</button>
                                        </div>
                                    </td>
                                    <td><?php echo number_format($item['total'], 2, ',', ' '); ?> €</td>
                                    <td>
                                        <a href="/MY-boutique/public/order/removeFromCart/<?php echo $item['product']->id; ?>" class="btn btn-outline-danger btn-sm">
                                            <i class="bi bi-trash"></i> Supprimer
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-end">Total :</th>
                                <th><?php echo number_format($total, 2, ',', ' '); ?> €</th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
                <div class="d-flex justify-content-between mt-3">
                    <a href="/MY-boutique/public/product" class="btn btn-outline-primary">
                        <i class="bi bi-arrow-left"></i> Continuer mes achats
                    </a>
                    <div>
                        <button type="submit" class="btn btn-secondary me-2">
                            <i class="bi bi-arrow-clockwise"></i> Mettre à jour le panier
                        </button>
                        <a href="/MY-boutique/public/order/checkout" class="btn btn-primary">
                            <i class="bi bi-credit-card"></i> Passer la commande
                        </a>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>
    
    <!-- Pied de page -->
    <?php require_once '../app/views/partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Script pour les boutons + et - de quantité
        document.addEventListener('DOMContentLoaded', function() {
            const quantityBtns = document.querySelectorAll('.quantity-btn');
            
            quantityBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const action = this.getAttribute('data-action');
                    const input = this.parentElement.querySelector('.quantity-input');
                    let value = parseInt(input.value);
                    
                    if (action === 'increase') {
                        if (value < parseInt(input.getAttribute('max'))) {
                            input.value = value + 1;
                        }
                    } else {
                        if (value > 1) {
                            input.value = value - 1;
                        }
                    }
                });
            });
        });
    </script>
</body>
</html> 