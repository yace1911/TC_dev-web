<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boutique - MY Boutique</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="/MY-boutique/public/assets/css/style.css">
</head>
<body>
    <!-- En-tête -->
    <?php require_once '../app/views/partials/header.php'; ?>
    
    <div class="container mt-4">
        <!-- Messages de succès/erreur -->
        <?php if(isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php 
                echo $_SESSION['success_message']; 
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>
        
        <?php if(isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?php 
                echo $_SESSION['error_message']; 
                unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Filtres de catégories -->
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-header">
                        <h4>Catégories</h4>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <a href="/MY-boutique/public/product" class="list-group-item list-group-item-action <?php echo !isset($currentCategory) ? 'active' : ''; ?>">
                                Toutes les catégories
                            </a>
                            <?php foreach($categories as $cat): ?>
                                <a href="/MY-boutique/public/product/category/<?php echo $cat->categorie; ?>" 
                                   class="list-group-item list-group-item-action <?php echo (isset($currentCategory) && $currentCategory === $cat->categorie) ? 'active' : ''; ?>">
                                    <?php echo $cat->categorie; ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="mt-3">
                            <a href="/MY-boutique/public/product/bestSellers" class="btn btn-outline-primary w-100">
                                <i class="bi bi-star-fill"></i> Meilleures ventes
                            </a>
                        </div>
                        
                        <?php if(isset($_SESSION['role']) && ($_SESSION['role'] === 'it' || $_SESSION['role'] === 'admin')): ?>
                            <div class="mt-3">
                                <a href="/MY-boutique/public/product/create" class="btn btn-success w-100">
                                    <i class="bi bi-plus-circle"></i> Ajouter un produit
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- Liste des produits -->
            <div class="col-md-9">
                <h2>Nos produits <?php echo isset($currentCategory) ? '- ' . $currentCategory : ''; ?></h2>
                
                <?php if(empty($products)): ?>
                    <div class="alert alert-info">
                        Aucun produit disponible dans cette catégorie.
                    </div>
                <?php else: ?>
                    <div class="row row-cols-1 row-cols-md-3 g-4">
                        <?php foreach($products as $product): ?>
                            <div class="col">
                                <div class="card h-100">
                                    <img src="<?php echo $product->image; ?>" class="card-img-top" alt="<?php echo $product->nom; ?>">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $product->nom; ?></h5>
                                        <p class="card-text"><?php echo substr($product->description, 0, 100) . '...'; ?></p>
                                        <p class="card-text fw-bold"><?php echo number_format($product->prix, 2, ',', ' '); ?> €</p>
                                        <div class="d-flex justify-content-between">
                                            <a href="/MY-boutique/public/product/show/<?php echo $product->id; ?>" class="btn btn-primary">
                                                Détails
                                            </a>
                                            <?php if(isset($_SESSION['user_id'])): ?>
                                                <form action="/MY-boutique/public/order/addToCart" method="POST">
                                                    <input type="hidden" name="product_id" value="<?php echo $product->id; ?>">
                                                    <input type="hidden" name="quantity" value="1">
                                                    <button type="submit" class="btn btn-outline-success" <?php echo $product->stock > 0 ? '' : 'disabled'; ?>>
                                                        Ajouter au panier
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                        <?php if($product->stock <= 0): ?>
                                            <p class="text-danger fw-bold mt-2">Rupture de stock</p>
                                        <?php elseif($product->stock < 5): ?>
                                            <p class="text-warning fw-bold mt-2">Plus que <?php echo $product->stock; ?> en stock</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Pied de page -->
    <?php require_once '../app/views/partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 