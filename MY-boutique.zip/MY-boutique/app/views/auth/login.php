<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - MY Boutique</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="/MY-boutique/public/assets/css/style.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Connexion</h3>
                    </div>
                    <div class="card-body">
                        <?php if(isset($_SESSION['success_message'])): ?>
                            <div class="alert alert-success">
                                <?php 
                                echo $_SESSION['success_message']; 
                                unset($_SESSION['success_message']);
                                ?>
                            </div>
                        <?php endif; ?>

                        <?php if(isset($errors['login'])): ?>
                            <div class="alert alert-danger">
                                <?php echo $errors['login']; ?>
                            </div>
                        <?php endif; ?>

                        <form action="/MY-boutique/public/auth/login" method="POST">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control <?php echo isset($errors['email']) ? 'is-invalid' : ''; ?>" 
                                       id="email" name="email" value="<?php echo isset($data['email']) ? $data['email'] : ''; ?>">
                                <?php if(isset($errors['email'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['email']; ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="mot_de_passe" class="form-label">Mot de passe</label>
                                <input type="password" class="form-control <?php echo isset($errors['mot_de_passe']) ? 'is-invalid' : ''; ?>" 
                                       id="mot_de_passe" name="mot_de_passe">
                                <?php if(isset($errors['mot_de_passe'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['mot_de_passe']; ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">Se connecter</button>
                            </div>
                        </form>
                        
                        <div class="mt-3 text-center">
                            <p>Vous n'avez pas de compte? <a href="/MY-boutique/public/auth/register">Inscrivez-vous</a></p>
                            <p><a href="/MY-boutique/public/auth/resetPassword">Mot de passe oublié?</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 