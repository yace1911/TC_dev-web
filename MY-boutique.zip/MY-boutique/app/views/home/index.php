<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MY Boutique - Votre destination mode préférée</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="/MY-boutique/public/assets/css/style.css">
</head>
<body>
    <!-- En-tête -->
    <?php require_once '../app/views/partials/header.php'; ?>
    
    <!-- Bannière principale -->
    <div class="banner py-5 bg-primary text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <h1 class="display-4">Bienvenue sur MY Boutique</h1>
                    <p class="lead">Votre destination mode préférée pour des vêtements et accessoires de qualité.</p>
                    <a href="/MY-boutique/public/product" class="btn btn-light btn-lg">Découvrir nos produits</a>
                </div>
                <div class="col-md-5 d-none d-md-block">
                    <img src="/MY-boutique/public/assets/images/banner.png" alt="MY Boutique" class="img-fluid rounded">
                </div>
            </div>
        </div>
    </div>
    
    <!-- Catégories -->
    <div class="container mt-5">
        <h2 class="text-center mb-4">Nos catégories</h2>
        <div class="row justify-content-center">
            <?php foreach($categories as $category): ?>
                <div class="col-md-3 mb-4">
                    <div class="card category-card text-center">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $category->categorie; ?></h5>
                            <a href="/MY-boutique/public/product/category/<?php echo $category->categorie; ?>" class="btn btn-outline-primary">Voir les produits</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Produits à la une -->
    <div class="container mt-5">
        <h2 class="text-center mb-4">Nos derniers produits</h2>
        <div class="row">
            <?php foreach($featuredProducts as $product): ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100">
                        <img src="<?php echo $product->image; ?>" class="card-img-top" alt="<?php echo $product->nom; ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $product->nom; ?></h5>
                            <p class="card-text"><?php echo substr($product->description, 0, 50) . '...'; ?></p>
                            <p class="card-text fw-bold"><?php echo number_format($product->prix, 2, ',', ' '); ?> €</p>
                            <a href="/MY-boutique/public/product/show/<?php echo $product->id; ?>" class="btn btn-primary">Détails</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-3">
            <a href="/MY-boutique/public/product" class="btn btn-outline-primary">Voir tous les produits</a>
        </div>
    </div>
    
    <!-- Événements à venir -->
    <div class="container mt-5">
        <h2 class="text-center mb-4">Événements à venir</h2>
        <div class="row">
            <?php if(empty($upcomingEvents)): ?>
                <div class="col-12 text-center">
                    <p>Aucun événement à venir pour le moment.</p>
                </div>
            <?php else: ?>
                <?php foreach($upcomingEvents as $event): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card event-card">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?php echo $event->image; ?>" class="img-fluid rounded-start" alt="<?php echo $event->titre; ?>">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo $event->titre; ?></h5>
                                        <p class="card-text"><?php echo substr($event->description, 0, 100) . '...'; ?></p>
                                        <p class="card-text"><small class="text-muted">Date: <?php echo date('d/m/Y', strtotime($event->date)); ?></small></p>
                                        <a href="/MY-boutique/public/event/show/<?php echo $event->id; ?>" class="btn btn-sm btn-outline-primary">En savoir plus</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="text-center mt-3">
            <a href="/MY-boutique/public/event" class="btn btn-outline-primary">Voir tous les événements</a>
        </div>
    </div>
    
    <!-- Pied de page -->
    <?php require_once '../app/views/partials/footer.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 