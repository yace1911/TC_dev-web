<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/MY-boutique/public">MY Boutique</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="/MY-boutique/public">Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/MY-boutique/public/product">Boutique</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/MY-boutique/public/event">Événements</a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-person-circle"></i> <?php echo $_SESSION['user_prenom'] . ' ' . $_SESSION['user_nom']; ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="/MY-boutique/public/profile">Mon profil</a></li>
                                <li><a class="dropdown-item" href="/MY-boutique/public/order/history">Mes commandes</a></li>
                                
                                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/MY-boutique/public/admin">Tableau de bord</a></li>
                                <?php endif; ?>
                                
                                <?php if(isset($_SESSION['role']) && ($_SESSION['role'] === 'it' || $_SESSION['role'] === 'admin')): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/MY-boutique/public/product/create">Ajouter un produit</a></li>
                                    <li><a class="dropdown-item" href="/MY-boutique/public/event/create">Ajouter un événement</a></li>
                                <?php endif; ?>
                                
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="/MY-boutique/public/auth/logout">Déconnexion</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link position-relative" href="/MY-boutique/public/order/cart">
                                <i class="bi bi-cart-fill"></i> Panier
                                <?php if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                        <?php echo count($_SESSION['cart']); ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/MY-boutique/public/auth/login">Connexion</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/MY-boutique/public/auth/register">Inscription</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header> 