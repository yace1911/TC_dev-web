<footer class="bg-dark text-white mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>MY Boutique</h5>
                <p>Votre destination mode préférée</p>
            </div>
            <div class="col-md-4">
                <h5>Liens utiles</h5>
                <ul class="list-unstyled">
                    <li><a href="/MY-boutique/public" class="text-white">Accueil</a></li>
                    <li><a href="/MY-boutique/public/product" class="text-white">Boutique</a></li>
                    <li><a href="/MY-boutique/public/event" class="text-white">Événements</a></li>
                    <li><a href="#" class="text-white">À propos</a></li>
                    <li><a href="#" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact</h5>
                <address>
                    <p>123 Avenue de la Mode</p>
                    <p>75000 Paris</p>
                    <p>Email: contact@myboutique.com</p>
                    <p>Tél: +33 1 23 45 67 89</p>
                </address>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-12 text-center">
                <p>&copy; <?php echo date('Y'); ?> MY Boutique - Tous droits réservés</p>
            </div>
        </div>
    </div>
</footer> 