<?php
class Product extends Model {
    public function getAllProducts() {
        $sql = "SELECT * FROM products ORDER BY nom";
        return $this->query($sql)->fetchAll();
    }
    
    public function getProductById($id) {
        $sql = "SELECT * FROM products WHERE id = :id";
        return $this->query($sql, ['id' => $id])->fetch();
    }
    
    public function getProductsByCategory($category) {
        $sql = "SELECT * FROM products WHERE categorie = :categorie ORDER BY nom";
        return $this->query($sql, ['categorie' => $category])->fetchAll();
    }
    
    public function getAllCategories() {
        $sql = "SELECT DISTINCT categorie FROM products ORDER BY categorie";
        return $this->query($sql)->fetchAll();
    }
    
    public function getFeaturedProducts($limit = 4) {
        $sql = "SELECT * FROM products ORDER BY date_creation DESC LIMIT :limit";
        return $this->query($sql, ['limit' => $limit])->fetchAll();
    }
    
    public function getBestSellersOfMonth() {
        $currentMonth = date('m');
        $currentYear = date('Y');
        
        $sql = "SELECT p.*, SUM(oi.quantite) as total_ventes, p.categorie
                FROM products p
                JOIN order_items oi ON p.id = oi.product_id
                JOIN orders o ON oi.order_id = o.id
                WHERE MONTH(o.date) = :month AND YEAR(o.date) = :year
                GROUP BY p.id, p.categorie
                ORDER BY p.categorie, total_ventes DESC";
                
        $bestSellers = $this->query($sql, [
            'month' => $currentMonth,
            'year' => $currentYear
        ])->fetchAll();
        
        // Organiser par catégorie
        $bestSellersByCategory = [];
        foreach ($bestSellers as $product) {
            if (!isset($bestSellersByCategory[$product->categorie])) {
                $bestSellersByCategory[$product->categorie] = [];
            }
            $bestSellersByCategory[$product->categorie][] = $product;
        }
        
        return $bestSellersByCategory;
    }
    
    public function addProduct($data) {
        try {
            $sql = "INSERT INTO products (nom, description, prix, stock, categorie, image) 
                    VALUES (:nom, :description, :prix, :stock, :categorie, :image)";
            
            $this->query($sql, [
                'nom' => $data['nom'],
                'description' => $data['description'],
                'prix' => $data['prix'],
                'stock' => $data['stock'],
                'categorie' => $data['categorie'],
                'image' => $data['image']
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function updateProduct($data) {
        try {
            $sql = "UPDATE products 
                    SET nom = :nom, 
                        description = :description, 
                        prix = :prix, 
                        stock = :stock, 
                        categorie = :categorie, 
                        image = :image 
                    WHERE id = :id";
            
            $this->query($sql, [
                'id' => $data['id'],
                'nom' => $data['nom'],
                'description' => $data['description'],
                'prix' => $data['prix'],
                'stock' => $data['stock'],
                'categorie' => $data['categorie'],
                'image' => $data['image']
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function deleteProduct($id) {
        try {
            // Supprimer d'abord les références dans order_items et comments
            $sql1 = "DELETE FROM order_items WHERE product_id = :id";
            $this->query($sql1, ['id' => $id]);
            
            $sql2 = "DELETE FROM comments WHERE product_id = :id";
            $this->query($sql2, ['id' => $id]);
            
            // Puis supprimer le produit
            $sql3 = "DELETE FROM products WHERE id = :id";
            $this->query($sql3, ['id' => $id]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function updateStock($id, $quantity) {
        try {
            $sql = "UPDATE products SET stock = stock - :quantity WHERE id = :id";
            $this->query($sql, [
                'id' => $id,
                'quantity' => $quantity
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
} 