<?php
class Order extends Model {
    public function createOrder($data) {
        try {
            $sql = "INSERT INTO orders (user_id, date, total, statut) 
                    VALUES (:user_id, NOW(), :total, :statut)";
            
            $this->query($sql, [
                'user_id' => $data['user_id'],
                'total' => $data['total'],
                'statut' => $data['statut']
            ]);
            
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function addOrderItem($data) {
        try {
            $sql = "INSERT INTO order_items (order_id, product_id, quantite, prix) 
                    VALUES (:order_id, :product_id, :quantite, :prix)";
            
            $this->query($sql, [
                'order_id' => $data['order_id'],
                'product_id' => $data['product_id'],
                'quantite' => $data['quantite'],
                'prix' => $data['prix']
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function getOrderById($id) {
        $sql = "SELECT o.*, u.nom, u.prenom, u.email, u.adresse 
                FROM orders o
                JOIN users u ON o.user_id = u.id
                WHERE o.id = :id";
        
        return $this->query($sql, ['id' => $id])->fetch();
    }
    
    public function getOrderItems($orderId) {
        $sql = "SELECT oi.*, p.nom, p.image, p.categorie
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = :order_id";
        
        return $this->query($sql, ['order_id' => $orderId])->fetchAll();
    }
    
    public function getOrdersByUserId($userId) {
        $sql = "SELECT * FROM orders WHERE user_id = :user_id ORDER BY date DESC";
        return $this->query($sql, ['user_id' => $userId])->fetchAll();
    }
    
    public function getAllOrders() {
        $sql = "SELECT o.*, u.nom, u.prenom, u.email
                FROM orders o
                JOIN users u ON o.user_id = u.id
                ORDER BY o.date DESC";
        
        return $this->query($sql)->fetchAll();
    }
    
    public function updateOrderStatus($id, $status) {
        try {
            $sql = "UPDATE orders SET statut = :statut WHERE id = :id";
            $this->query($sql, [
                'id' => $id,
                'statut' => $status
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function getTotalSales() {
        $sql = "SELECT SUM(total) as total_sales FROM orders WHERE statut != 'annulée'";
        $result = $this->query($sql)->fetch();
        return $result->total_sales ?? 0;
    }
    
    public function getMonthlySales($year) {
        $sql = "SELECT MONTH(date) as month, SUM(total) as total
                FROM orders 
                WHERE YEAR(date) = :year AND statut != 'annulée'
                GROUP BY MONTH(date)
                ORDER BY MONTH(date)";
        
        return $this->query($sql, ['year' => $year])->fetchAll();
    }
    
    public function getSalesByCategory() {
        $sql = "SELECT p.categorie, SUM(oi.quantite) as quantity, SUM(oi.quantite * oi.prix) as total
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                JOIN orders o ON oi.order_id = o.id
                WHERE o.statut != 'annulée'
                GROUP BY p.categorie
                ORDER BY total DESC";
        
        return $this->query($sql)->fetchAll();
    }
} 