<?php
class User extends Model {
    public function register($data) {
        try {
            $sql = "INSERT INTO users (nom, prenom, adresse, email, mot_de_passe, carte_bancaire, role) 
                    VALUES (:nom, :prenom, :adresse, :email, :mot_de_passe, :carte_bancaire, 'client')";
            
            $this->query($sql, [
                'nom' => $data['nom'],
                'prenom' => $data['prenom'],
                'adresse' => $data['adresse'],
                'email' => $data['email'],
                'mot_de_passe' => $data['mot_de_passe'],
                'carte_bancaire' => $data['carte_bancaire']
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function findUserByEmail($email) {
        $sql = "SELECT * FROM users WHERE email = :email";
        $stmt = $this->query($sql, ['email' => $email]);
        return $stmt->fetch();
    }
    
    public function login($email, $password) {
        $user = $this->findUserByEmail($email);
        
        if ($user && password_verify($password, $user->mot_de_passe)) {
            return $user;
        }
        
        return false;
    }
    
    public function updateProfile($id, $data) {
        try {
            $sql = "UPDATE users SET nom = :nom, prenom = :prenom, adresse = :adresse";
            
            $params = [
                'id' => $id,
                'nom' => $data['nom'],
                'prenom' => $data['prenom'],
                'adresse' => $data['adresse']
            ];
            
            // Ajoute la carte bancaire seulement si fournie
            if (!empty($data['carte_bancaire'])) {
                $sql .= ", carte_bancaire = :carte_bancaire";
                $params['carte_bancaire'] = $data['carte_bancaire'];
            }
            
            $sql .= " WHERE id = :id";
            
            $this->query($sql, $params);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function updatePassword($id, $password) {
        try {
            $sql = "UPDATE users SET mot_de_passe = :mot_de_passe WHERE id = :id";
            $this->query($sql, [
                'id' => $id,
                'mot_de_passe' => password_hash($password, PASSWORD_DEFAULT)
            ]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function getAllUsers() {
        $sql = "SELECT * FROM users";
        return $this->query($sql)->fetchAll();
    }
    
    public function deleteUser($id) {
        try {
            $sql = "DELETE FROM users WHERE id = :id";
            $this->query($sql, ['id' => $id]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
} 