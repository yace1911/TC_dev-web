<?php
class Event extends Model {
    public function getAllEvents() {
        $sql = "SELECT * FROM events ORDER BY date DESC";
        return $this->query($sql)->fetchAll();
    }
    
    public function getValidatedEvents() {
        $sql = "SELECT * FROM events WHERE valide = 1 ORDER BY date DESC";
        return $this->query($sql)->fetchAll();
    }
    
    public function getUpcomingEvents($limit = 3) {
        $today = date('Y-m-d');
        $sql = "SELECT * FROM events 
                WHERE valide = 1 AND date >= :today 
                ORDER BY date ASC 
                LIMIT :limit";
        
        return $this->query($sql, [
            'today' => $today,
            'limit' => $limit
        ])->fetchAll();
    }
    
    public function getPendingEvents() {
        $sql = "SELECT * FROM events WHERE valide = 0 ORDER BY date DESC";
        return $this->query($sql)->fetchAll();
    }
    
    public function getEventById($id) {
        $sql = "SELECT * FROM events WHERE id = :id";
        return $this->query($sql, ['id' => $id])->fetch();
    }
    
    public function getEventsByUser($userId) {
        $sql = "SELECT * FROM events WHERE user_id = :user_id ORDER BY date DESC";
        return $this->query($sql, ['user_id' => $userId])->fetchAll();
    }
    
    public function addEvent($data, $valide = 0) {
        try {
            $sql = "INSERT INTO events (titre, description, image, date, valide, user_id) 
                    VALUES (:titre, :description, :image, :date, :valide, :user_id)";
            
            $this->query($sql, [
                'titre' => $data['titre'],
                'description' => $data['description'],
                'image' => $data['image'],
                'date' => $data['date'],
                'valide' => $valide,
                'user_id' => $_SESSION['user_id']
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function updateEvent($data, $valide = 0) {
        try {
            $sql = "UPDATE events 
                    SET titre = :titre, 
                        description = :description, 
                        image = :image, 
                        date = :date,
                        valide = :valide
                    WHERE id = :id";
            
            $this->query($sql, [
                'id' => $data['id'],
                'titre' => $data['titre'],
                'description' => $data['description'],
                'image' => $data['image'],
                'date' => $data['date'],
                'valide' => $valide
            ]);
            
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function validateEvent($id) {
        try {
            $sql = "UPDATE events SET valide = 1 WHERE id = :id";
            $this->query($sql, ['id' => $id]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function deleteEvent($id) {
        try {
            $sql = "DELETE FROM events WHERE id = :id";
            $this->query($sql, ['id' => $id]);
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }
} 