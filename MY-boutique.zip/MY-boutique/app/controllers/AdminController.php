<?php
class AdminController extends Controller {
    public function __construct() {
        // Vérifier si l'utilisateur est admin
        if (!$this->isLoggedIn() || !$this->isAdmin()) {
            $this->redirect('auth/login');
        }
        
        $this->orderModel = $this->model('Order');
        $this->userModel = $this->model('User');
        $this->eventModel = $this->model('Event');
    }
    
    public function index() {
        // Statistiques pour le tableau de bord
        $totalSales = $this->orderModel->getTotalSales();
        $monthlySales = $this->orderModel->getMonthlySales(date('Y'));
        $salesByCategory = $this->orderModel->getSalesByCategory();
        
        // Événements en attente de validation
        $pendingEvents = $this->eventModel->getPendingEvents();
        
        // Dernières commandes
        $recentOrders = $this->orderModel->getAllOrders();
        
        // Liste des utilisateurs
        $users = $this->userModel->getAllUsers();
        
        $this->view('admin/dashboard', [
            'totalSales' => $totalSales,
            'monthlySales' => $monthlySales,
            'salesByCategory' => $salesByCategory,
            'pendingEvents' => $pendingEvents,
            'recentOrders' => $recentOrders,
            'users' => $users
        ]);
    }
    
    public function users() {
        // Liste des utilisateurs
        $users = $this->userModel->getAllUsers();
        
        $this->view('admin/users', [
            'users' => $users
        ]);
    }
    
    public function deleteUser($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if ($this->userModel->deleteUser($id)) {
                $_SESSION['success_message'] = 'Utilisateur supprimé avec succès.';
            } else {
                $_SESSION['error_message'] = 'Erreur lors de la suppression de l\'utilisateur.';
            }
        }
        
        $this->redirect('admin/users');
    }
    
    public function events() {
        // Tous les événements
        $events = $this->eventModel->getAllEvents();
        
        $this->view('admin/events', [
            'events' => $events
        ]);
    }
    
    public function validateEvent($id) {
        if ($this->eventModel->validateEvent($id)) {
            $_SESSION['success_message'] = 'Événement validé avec succès.';
        } else {
            $_SESSION['error_message'] = 'Erreur lors de la validation de l\'événement.';
        }
        
        $this->redirect('admin/events');
    }
    
    public function rejectEvent($id) {
        if ($this->eventModel->deleteEvent($id)) {
            $_SESSION['success_message'] = 'Événement refusé et supprimé avec succès.';
        } else {
            $_SESSION['error_message'] = 'Erreur lors de la suppression de l\'événement.';
        }
        
        $this->redirect('admin/events');
    }
    
    public function orders() {
        // Toutes les commandes
        $orders = $this->orderModel->getAllOrders();
        
        $this->view('admin/orders', [
            'orders' => $orders
        ]);
    }
    
    public function orderDetails($id) {
        // Détails d'une commande
        $order = $this->orderModel->getOrderById($id);
        $orderItems = $this->orderModel->getOrderItems($id);
        
        $this->view('admin/order_details', [
            'order' => $order,
            'orderItems' => $orderItems
        ]);
    }
    
    public function updateOrderStatus($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['status'])) {
            $status = $_POST['status'];
            
            if ($this->orderModel->updateOrderStatus($id, $status)) {
                $_SESSION['success_message'] = 'Statut de la commande mis à jour avec succès.';
            } else {
                $_SESSION['error_message'] = 'Erreur lors de la mise à jour du statut de la commande.';
            }
        }
        
        $this->redirect('admin/orderDetails/' . $id);
    }
    
    public function salesReport() {
        // Données pour le rapport de ventes
        $year = isset($_GET['year']) ? $_GET['year'] : date('Y');
        
        $monthlySales = $this->orderModel->getMonthlySales($year);
        $salesByCategory = $this->orderModel->getSalesByCategory();
        
        $this->view('admin/sales_report', [
            'year' => $year,
            'monthlySales' => $monthlySales,
            'salesByCategory' => $salesByCategory
        ]);
    }
} 