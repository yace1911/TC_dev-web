<?php
class HomeController extends Controller {
    public function __construct() {
        $this->productModel = $this->model('Product');
        $this->eventModel = $this->model('Event');
    }
    
    public function index() {
        // Récupérer les produits phares (4 derniers produits)
        $featuredProducts = $this->productModel->getFeaturedProducts(4);
        
        // Récupérer les événements à venir
        $upcomingEvents = $this->eventModel->getUpcomingEvents(2);
        
        // Récupérer les catégories de produits
        $categories = $this->productModel->getAllCategories();
        
        $this->view('home/index', [
            'featuredProducts' => $featuredProducts,
            'upcomingEvents' => $upcomingEvents,
            'categories' => $categories
        ]);
    }
} 