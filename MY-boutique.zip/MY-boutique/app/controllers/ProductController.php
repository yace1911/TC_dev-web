<?php
class ProductController extends Controller {
    public function __construct() {
        $this->productModel = $this->model('Product');
    }
    
    public function index() {
        // Récupérer tous les produits
        $products = $this->productModel->getAllProducts();
        
        // Récupérer les catégories pour le filtre
        $categories = $this->productModel->getAllCategories();
        
        $this->view('products/index', [
            'products' => $products,
            'categories' => $categories
        ]);
    }
    
    public function show($id) {
        // Récupérer le produit par son ID
        $product = $this->productModel->getProductById($id);
        
        if (!$product) {
            // Produit non trouvé, rediriger vers la liste des produits
            $this->redirect('product');
        }
        
        // Récupérer les commentaires du produit
        $commentModel = $this->model('Comment');
        $comments = $commentModel->getCommentsByProductId($id);
        
        $this->view('products/show', [
            'product' => $product,
            'comments' => $comments
        ]);
    }
    
    public function category($category) {
        // Récupérer les produits par catégorie
        $products = $this->productModel->getProductsByCategory($category);
        
        // Récupérer toutes les catégories pour le filtre
        $categories = $this->productModel->getAllCategories();
        
        $this->view('products/index', [
            'products' => $products,
            'categories' => $categories,
            'currentCategory' => $category
        ]);
    }
    
    public function bestSellers() {
        // Récupérer les meilleures ventes du mois courant
        $bestSellers = $this->productModel->getBestSellersOfMonth();
        
        $this->view('products/best_sellers', [
            'bestSellers' => $bestSellers
        ]);
    }
    
    // Méthodes pour les utilisateurs IT/Commercial
    public function create() {
        // Vérifier si l'utilisateur est IT/Commercial ou admin
        if (!$this->isIT() && !$this->isAdmin()) {
            $this->redirect('auth/login');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Traitement de l'image
            $imagePath = '';
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $uploadDir = '../public/assets/uploads/products/';
                
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $imageName = time() . '_' . $_FILES['image']['name'];
                $imagePath = $uploadDir . $imageName;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
                    $imagePath = '/MY-boutique/public/assets/uploads/products/' . $imageName;
                }
            }
            
            // Données du produit
            $data = [
                'nom' => trim($_POST['nom']),
                'description' => trim($_POST['description']),
                'prix' => floatval($_POST['prix']),
                'stock' => intval($_POST['stock']),
                'categorie' => trim($_POST['categorie']),
                'image' => $imagePath,
                'errors' => []
            ];
            
            // Validation
            if (empty($data['nom'])) {
                $data['errors']['nom'] = 'Le nom du produit est requis';
            }
            if (empty($data['description'])) {
                $data['errors']['description'] = 'La description est requise';
            }
            if ($data['prix'] <= 0) {
                $data['errors']['prix'] = 'Le prix doit être supérieur à 0';
            }
            if ($data['stock'] < 0) {
                $data['errors']['stock'] = 'Le stock ne peut pas être négatif';
            }
            if (empty($data['categorie'])) {
                $data['errors']['categorie'] = 'La catégorie est requise';
            }
            if (empty($data['image'])) {
                $data['errors']['image'] = 'Une image est requise';
            }
            
            // S'il n'y a pas d'erreurs, ajouter le produit
            if (empty($data['errors'])) {
                if ($this->productModel->addProduct($data)) {
                    $_SESSION['success_message'] = 'Le produit a été ajouté avec succès';
                    $this->redirect('product');
                } else {
                    $data['errors']['db'] = 'Erreur lors de l\'ajout du produit';
                    $this->view('products/create', $data);
                }
            } else {
                $this->view('products/create', $data);
            }
        } else {
            $this->view('products/create');
        }
    }
    
    public function edit($id) {
        // Vérifier si l'utilisateur est IT/Commercial ou admin
        if (!$this->isIT() && !$this->isAdmin()) {
            $this->redirect('auth/login');
        }
        
        // Récupérer le produit par son ID
        $product = $this->productModel->getProductById($id);
        
        if (!$product) {
            $this->redirect('product');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Traitement de l'image si une nouvelle est fournie
            $imagePath = $product->image;
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $uploadDir = '../public/assets/uploads/products/';
                
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $imageName = time() . '_' . $_FILES['image']['name'];
                $imagePath = $uploadDir . $imageName;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
                    $imagePath = '/MY-boutique/public/assets/uploads/products/' . $imageName;
                }
            }
            
            // Données du produit
            $data = [
                'id' => $id,
                'nom' => trim($_POST['nom']),
                'description' => trim($_POST['description']),
                'prix' => floatval($_POST['prix']),
                'stock' => intval($_POST['stock']),
                'categorie' => trim($_POST['categorie']),
                'image' => $imagePath,
                'errors' => []
            ];
            
            // Validation
            if (empty($data['nom'])) {
                $data['errors']['nom'] = 'Le nom du produit est requis';
            }
            if (empty($data['description'])) {
                $data['errors']['description'] = 'La description est requise';
            }
            if ($data['prix'] <= 0) {
                $data['errors']['prix'] = 'Le prix doit être supérieur à 0';
            }
            if ($data['stock'] < 0) {
                $data['errors']['stock'] = 'Le stock ne peut pas être négatif';
            }
            if (empty($data['categorie'])) {
                $data['errors']['categorie'] = 'La catégorie est requise';
            }
            
            // S'il n'y a pas d'erreurs, modifier le produit
            if (empty($data['errors'])) {
                if ($this->productModel->updateProduct($data)) {
                    $_SESSION['success_message'] = 'Le produit a été mis à jour avec succès';
                    $this->redirect('product/show/' . $id);
                } else {
                    $data['errors']['db'] = 'Erreur lors de la mise à jour du produit';
                    $this->view('products/edit', ['product' => (object)$data, 'errors' => $data['errors']]);
                }
            } else {
                $this->view('products/edit', ['product' => (object)$data, 'errors' => $data['errors']]);
            }
        } else {
            $this->view('products/edit', ['product' => $product]);
        }
    }
    
    public function delete($id) {
        // Vérifier si l'utilisateur est IT/Commercial ou admin
        if (!$this->isIT() && !$this->isAdmin()) {
            $this->redirect('auth/login');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if ($this->productModel->deleteProduct($id)) {
                $_SESSION['success_message'] = 'Le produit a été supprimé avec succès';
            } else {
                $_SESSION['error_message'] = 'Erreur lors de la suppression du produit';
            }
        }
        
        $this->redirect('product');
    }
} 