<?php
class EventController extends Controller {
    public function __construct() {
        $this->eventModel = $this->model('Event');
    }
    
    public function index() {
        // Récupérer tous les événements validés
        $events = $this->eventModel->getValidatedEvents();
        
        $this->view('events/index', [
            'events' => $events
        ]);
    }
    
    public function show($id) {
        // Récupérer l'événement par son ID
        $event = $this->eventModel->getEventById($id);
        
        // Vérifier si l'événement existe et est validé (ou si l'utilisateur est IT/Commercial ou admin)
        if (!$event || (!$event->valide && !$this->isIT() && !$this->isAdmin())) {
            $this->redirect('event');
        }
        
        $this->view('events/show', [
            'event' => $event
        ]);
    }
    
    public function create() {
        // Vérifier si l'utilisateur est IT/Commercial ou admin
        if (!$this->isIT() && !$this->isAdmin()) {
            $this->redirect('auth/login');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Traitement de l'image
            $imagePath = '';
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $uploadDir = '../public/assets/uploads/events/';
                
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $imageName = time() . '_' . $_FILES['image']['name'];
                $imagePath = $uploadDir . $imageName;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
                    $imagePath = '/MY-boutique/public/assets/uploads/events/' . $imageName;
                }
            }
            
            // Données de l'événement
            $data = [
                'titre' => trim($_POST['titre']),
                'description' => trim($_POST['description']),
                'date' => trim($_POST['date']),
                'image' => $imagePath,
                'errors' => []
            ];
            
            // Validation
            if (empty($data['titre'])) {
                $data['errors']['titre'] = 'Le titre est requis';
            }
            if (empty($data['description'])) {
                $data['errors']['description'] = 'La description est requise';
            }
            if (empty($data['date'])) {
                $data['errors']['date'] = 'La date est requise';
            }
            if (empty($data['image'])) {
                $data['errors']['image'] = 'Une image est requise';
            }
            
            // Si l'utilisateur est admin, validez automatiquement l'événement
            $valide = $this->isAdmin() ? 1 : 0;
            
            // S'il n'y a pas d'erreurs, ajouter l'événement
            if (empty($data['errors'])) {
                if ($this->eventModel->addEvent($data, $valide)) {
                    $_SESSION['success_message'] = $valide ? 
                        'L\'événement a été ajouté avec succès.' : 
                        'L\'événement a été soumis et est en attente de validation par un administrateur.';
                    $this->redirect('event');
                } else {
                    $data['errors']['db'] = 'Erreur lors de l\'ajout de l\'événement.';
                    $this->view('events/create', $data);
                }
            } else {
                $this->view('events/create', $data);
            }
        } else {
            $this->view('events/create');
        }
    }
    
    public function edit($id) {
        // Vérifier si l'utilisateur est IT/Commercial ou admin
        if (!$this->isIT() && !$this->isAdmin()) {
            $this->redirect('auth/login');
        }
        
        // Récupérer l'événement par son ID
        $event = $this->eventModel->getEventById($id);
        
        if (!$event) {
            $this->redirect('event');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Traitement de l'image si une nouvelle est fournie
            $imagePath = $event->image;
            if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                $uploadDir = '../public/assets/uploads/events/';
                
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $imageName = time() . '_' . $_FILES['image']['name'];
                $imagePath = $uploadDir . $imageName;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
                    $imagePath = '/MY-boutique/public/assets/uploads/events/' . $imageName;
                }
            }
            
            // Données de l'événement
            $data = [
                'id' => $id,
                'titre' => trim($_POST['titre']),
                'description' => trim($_POST['description']),
                'date' => trim($_POST['date']),
                'image' => $imagePath,
                'errors' => []
            ];
            
            // Validation
            if (empty($data['titre'])) {
                $data['errors']['titre'] = 'Le titre est requis';
            }
            if (empty($data['description'])) {
                $data['errors']['description'] = 'La description est requise';
            }
            if (empty($data['date'])) {
                $data['errors']['date'] = 'La date est requise';
            }
            
            // Si l'utilisateur est admin, validez automatiquement l'événement
            $valide = $this->isAdmin() ? 1 : $event->valide;
            
            // S'il n'y a pas d'erreurs, modifier l'événement
            if (empty($data['errors'])) {
                if ($this->eventModel->updateEvent($data, $valide)) {
                    $_SESSION['success_message'] = 'L\'événement a été mis à jour avec succès.';
                    $this->redirect('event/show/' . $id);
                } else {
                    $data['errors']['db'] = 'Erreur lors de la mise à jour de l\'événement.';
                    $this->view('events/edit', ['event' => (object)$data, 'errors' => $data['errors']]);
                }
            } else {
                $this->view('events/edit', ['event' => (object)$data, 'errors' => $data['errors']]);
            }
        } else {
            $this->view('events/edit', ['event' => $event]);
        }
    }
    
    public function delete($id) {
        // Vérifier si l'utilisateur est IT/Commercial ou admin
        if (!$this->isIT() && !$this->isAdmin()) {
            $this->redirect('auth/login');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if ($this->eventModel->deleteEvent($id)) {
                $_SESSION['success_message'] = 'L\'événement a été supprimé avec succès.';
            } else {
                $_SESSION['error_message'] = 'Erreur lors de la suppression de l\'événement.';
            }
        }
        
        $this->redirect('event');
    }
    
    public function manage() {
        // Vérifier si l'utilisateur est IT/Commercial ou admin
        if (!$this->isIT() && !$this->isAdmin()) {
            $this->redirect('auth/login');
        }
        
        // Récupérer tous les événements de l'utilisateur IT/Commercial
        $events = $this->isAdmin() ? 
            $this->eventModel->getAllEvents() : 
            $this->eventModel->getEventsByUser($_SESSION['user_id']);
        
        $this->view('events/manage', [
            'events' => $events
        ]);
    }
} 