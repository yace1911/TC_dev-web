<?php
class OrderController extends Controller {
    public function __construct() {
        $this->orderModel = $this->model('Order');
        $this->productModel = $this->model('Product');
    }
    
    public function index() {
        $this->redirect('order/cart');
    }
    
    public function cart() {
        $cartItems = [];
        $total = 0;
        
        // Si le panier existe et n'est pas vide
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $id => $quantity) {
                $product = $this->productModel->getProductById($id);
                
                if ($product) {
                    $productTotal = $product->prix * $quantity;
                    $total += $productTotal;
                    
                    $cartItems[] = [
                        'product' => $product,
                        'quantity' => $quantity,
                        'total' => $productTotal
                    ];
                }
            }
        }
        
        $this->view('orders/cart', [
            'cartItems' => $cartItems,
            'total' => $total
        ]);
    }
    
    public function addToCart() {
        // Vérifier si l'utilisateur est connecté
        if (!$this->isLoggedIn()) {
            $_SESSION['error_message'] = 'Veuillez vous connecter pour ajouter des produits au panier.';
            $this->redirect('auth/login');
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $productId = isset($_POST['product_id']) ? $_POST['product_id'] : null;
            $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
            
            if ($productId && $quantity > 0) {
                // Vérifier si le produit existe et est en stock
                $product = $this->productModel->getProductById($productId);
                
                if ($product && $product->stock >= $quantity) {
                    // Initialiser le panier si nécessaire
                    if (!isset($_SESSION['cart'])) {
                        $_SESSION['cart'] = [];
                    }
                    
                    // Ajouter le produit au panier ou mettre à jour la quantité
                    if (isset($_SESSION['cart'][$productId])) {
                        // Vérifier si le stock est suffisant pour la nouvelle quantité
                        $newQuantity = $_SESSION['cart'][$productId] + $quantity;
                        
                        if ($product->stock >= $newQuantity) {
                            $_SESSION['cart'][$productId] = $newQuantity;
                            $_SESSION['success_message'] = 'Quantité mise à jour dans le panier.';
                        } else {
                            $_SESSION['error_message'] = 'Stock insuffisant pour ajouter cette quantité.';
                        }
                    } else {
                        $_SESSION['cart'][$productId] = $quantity;
                        $_SESSION['success_message'] = 'Produit ajouté au panier.';
                    }
                } else {
                    $_SESSION['error_message'] = 'Produit indisponible ou stock insuffisant.';
                }
            }
            
            // Rediriger vers la page précédente ou le panier
            $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '/MY-boutique/public/product';
            header('Location: ' . $referer);
            exit;
        }
        
        $this->redirect('product');
    }
    
    public function updateCart() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cart'])) {
            foreach ($_POST['cart'] as $productId => $quantity) {
                $quantity = (int)$quantity;
                
                if ($quantity > 0) {
                    // Vérifier le stock
                    $product = $this->productModel->getProductById($productId);
                    
                    if ($product && $product->stock >= $quantity) {
                        $_SESSION['cart'][$productId] = $quantity;
                    } else {
                        $_SESSION['error_message'] = 'Stock insuffisant pour le produit ' . $product->nom;
                    }
                } else {
                    // Supprimer du panier si quantité <= 0
                    unset($_SESSION['cart'][$productId]);
                }
            }
            
            $_SESSION['success_message'] = 'Panier mis à jour.';
        }
        
        $this->redirect('order/cart');
    }
    
    public function removeFromCart($productId) {
        if (isset($_SESSION['cart'][$productId])) {
            unset($_SESSION['cart'][$productId]);
            $_SESSION['success_message'] = 'Produit supprimé du panier.';
        }
        
        $this->redirect('order/cart');
    }
    
    public function checkout() {
        // Vérifier si l'utilisateur est connecté
        if (!$this->isLoggedIn()) {
            $_SESSION['error_message'] = 'Veuillez vous connecter pour finaliser votre commande.';
            $this->redirect('auth/login');
        }
        
        // Vérifier si le panier n'est pas vide
        if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
            $_SESSION['error_message'] = 'Votre panier est vide.';
            $this->redirect('order/cart');
        }
        
        // Récupérer les informations de l'utilisateur
        $userModel = $this->model('User');
        $user = $userModel->findById('users', $_SESSION['user_id']);
        
        // Calculer le total de la commande
        $cartItems = [];
        $total = 0;
        
        foreach ($_SESSION['cart'] as $id => $quantity) {
            $product = $this->productModel->getProductById($id);
            
            if ($product) {
                $productTotal = $product->prix * $quantity;
                $total += $productTotal;
                
                $cartItems[] = [
                    'product' => $product,
                    'quantity' => $quantity,
                    'total' => $productTotal
                ];
            }
        }
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Vérifier si tous les produits sont encore disponibles
            $outOfStock = false;
            
            foreach ($cartItems as $item) {
                $product = $item['product'];
                $quantity = $item['quantity'];
                
                if ($product->stock < $quantity) {
                    $outOfStock = true;
                    $_SESSION['error_message'] = 'Le produit "' . $product->nom . '" n\'est plus disponible en quantité demandée.';
                    break;
                }
            }
            
            if (!$outOfStock) {
                // Créer la commande
                $orderData = [
                    'user_id' => $_SESSION['user_id'],
                    'total' => $total,
                    'statut' => 'en cours'
                ];
                
                $orderId = $this->orderModel->createOrder($orderData);
                
                if ($orderId) {
                    // Ajouter les articles de la commande et mettre à jour les stocks
                    foreach ($cartItems as $item) {
                        $product = $item['product'];
                        $quantity = $item['quantity'];
                        
                        $orderItemData = [
                            'order_id' => $orderId,
                            'product_id' => $product->id,
                            'quantite' => $quantity,
                            'prix' => $product->prix
                        ];
                        
                        $this->orderModel->addOrderItem($orderItemData);
                        
                        // Mettre à jour le stock
                        $this->productModel->updateStock($product->id, $quantity);
                    }
                    
                    // Vider le panier
                    unset($_SESSION['cart']);
                    
                    // Envoyer un email de confirmation (bonus)
                    $this->sendOrderConfirmationEmail($user, $orderId, $cartItems, $total);
                    
                    $_SESSION['success_message'] = 'Commande effectuée avec succès. Un email de confirmation vous a été envoyé.';
                    $this->redirect('order/confirmation/' . $orderId);
                } else {
                    $_SESSION['error_message'] = 'Erreur lors de la création de la commande.';
                    $this->view('orders/checkout', [
                        'user' => $user,
                        'cartItems' => $cartItems,
                        'total' => $total
                    ]);
                }
            } else {
                $this->redirect('order/cart');
            }
        } else {
            $this->view('orders/checkout', [
                'user' => $user,
                'cartItems' => $cartItems,
                'total' => $total
            ]);
        }
    }
    
    public function confirmation($orderId) {
        // Vérifier si l'utilisateur est connecté
        if (!$this->isLoggedIn()) {
            $this->redirect('auth/login');
        }
        
        // Récupérer les informations de la commande
        $order = $this->orderModel->getOrderById($orderId);
        
        // Vérifier si la commande appartient à l'utilisateur connecté
        if (!$order || $order->user_id != $_SESSION['user_id']) {
            $this->redirect('order/history');
        }
        
        // Récupérer les articles de la commande
        $orderItems = $this->orderModel->getOrderItems($orderId);
        
        $this->view('orders/confirmation', [
            'order' => $order,
            'orderItems' => $orderItems
        ]);
    }
    
    public function history() {
        // Vérifier si l'utilisateur est connecté
        if (!$this->isLoggedIn()) {
            $this->redirect('auth/login');
        }
        
        // Récupérer l'historique des commandes de l'utilisateur
        $orders = $this->orderModel->getOrdersByUserId($_SESSION['user_id']);
        
        $this->view('orders/history', [
            'orders' => $orders
        ]);
    }
    
    public function details($orderId) {
        // Vérifier si l'utilisateur est connecté
        if (!$this->isLoggedIn()) {
            $this->redirect('auth/login');
        }
        
        // Récupérer les informations de la commande
        $order = $this->orderModel->getOrderById($orderId);
        
        // Vérifier si la commande appartient à l'utilisateur connecté ou si c'est un admin
        if (!$order || ($order->user_id != $_SESSION['user_id'] && !$this->isAdmin())) {
            $this->redirect('order/history');
        }
        
        // Récupérer les articles de la commande
        $orderItems = $this->orderModel->getOrderItems($orderId);
        
        $this->view('orders/details', [
            'order' => $order,
            'orderItems' => $orderItems
        ]);
    }
    
    private function sendOrderConfirmationEmail($user, $orderId, $cartItems, $total) {
        // Implémentation de l'envoi d'email (bonus)
        // Cette fonction est un placeholder pour l'envoi d'email
        // En production, vous utiliseriez PHPMailer ou une autre bibliothèque
        
        // Exemple de code (non fonctionnel):
        /*
        $to = $user->email;
        $subject = 'Confirmation de commande #' . $orderId;
        
        $message = "Bonjour " . $user->prenom . ",\n\n";
        $message .= "Votre commande #" . $orderId . " a été confirmée.\n\n";
        $message .= "Détails de la commande:\n";
        
        foreach ($cartItems as $item) {
            $message .= $item['product']->nom . " x " . $item['quantity'] . " : " . number_format($item['total'], 2, ',', ' ') . " €\n";
        }
        
        $message .= "\nTotal: " . number_format($total, 2, ',', ' ') . " €\n\n";
        $message .= "Merci pour votre achat!\n";
        $message .= "L'équipe MY Boutique";
        
        $headers = "From: noreply@myboutique.com";
        
        mail($to, $subject, $message, $headers);
        */
        
        // Pour les besoins du projet, on simule simplement l'envoi d'email
        return true;
    }
} 