<?php
class AuthController extends Controller {
    public function __construct() {
        $this->userModel = $this->model('User');
    }
    
    public function index() {
        // Page de connexion
        $this->view('auth/login');
    }
    
    public function register() {
        // Si c'est une soumission de formulaire
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Valider les données
            $data = [
                'nom' => trim($_POST['nom']),
                'prenom' => trim($_POST['prenom']),
                'adresse' => trim($_POST['adresse']),
                'email' => trim($_POST['email']),
                'mot_de_passe' => trim($_POST['mot_de_passe']),
                'carte_bancaire' => !empty($_POST['carte_bancaire']) ? trim($_POST['carte_bancaire']) : null,
                'errors' => []
            ];
            
            // Validation simple
            if (empty($data['nom'])) {
                $data['errors']['nom'] = 'Le nom est requis';
            }
            if (empty($data['prenom'])) {
                $data['errors']['prenom'] = 'Le prénom est requis';
            }
            if (empty($data['adresse'])) {
                $data['errors']['adresse'] = 'L\'adresse est requise';
            }
            if (empty($data['email'])) {
                $data['errors']['email'] = 'L\'email est requis';
            } elseif ($this->userModel->findUserByEmail($data['email'])) {
                $data['errors']['email'] = 'Cette adresse email est déjà utilisée';
            }
            if (empty($data['mot_de_passe'])) {
                $data['errors']['mot_de_passe'] = 'Le mot de passe est requis';
            } elseif (strlen($data['mot_de_passe']) < 6) {
                $data['errors']['mot_de_passe'] = 'Le mot de passe doit avoir au moins 6 caractères';
            }
            
            // S'il n'y a pas d'erreurs, enregistrer l'utilisateur
            if (empty($data['errors'])) {
                // Hash le mot de passe
                $data['mot_de_passe'] = password_hash($data['mot_de_passe'], PASSWORD_DEFAULT);
                
                // Enregistrement dans la BDD
                if ($this->userModel->register($data)) {
                    // Message de succès
                    $_SESSION['success_message'] = 'Inscription réussie ! Vous pouvez maintenant vous connecter.';
                    $this->redirect('auth/login');
                } else {
                    // Erreur
                    $this->view('auth/register', ['errors' => ['db' => 'Erreur lors de l\'inscription'], 'data' => $data]);
                }
            } else {
                // Afficher le formulaire avec les erreurs
                $this->view('auth/register', ['errors' => $data['errors'], 'data' => $data]);
            }
        } else {
            // Afficher le formulaire d'inscription
            $this->view('auth/register');
        }
    }
    
    public function login() {
        // Si c'est une soumission de formulaire
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Valider les données
            $data = [
                'email' => trim($_POST['email']),
                'mot_de_passe' => trim($_POST['mot_de_passe']),
                'errors' => []
            ];
            
            // Validation simple
            if (empty($data['email'])) {
                $data['errors']['email'] = 'L\'email est requis';
            }
            if (empty($data['mot_de_passe'])) {
                $data['errors']['mot_de_passe'] = 'Le mot de passe est requis';
            }
            
            // S'il n'y a pas d'erreurs, connecter l'utilisateur
            if (empty($data['errors'])) {
                // Vérifier l'utilisateur
                $user = $this->userModel->login($data['email'], $data['mot_de_passe']);
                
                if ($user) {
                    // Création de la session
                    $_SESSION['user_id'] = $user->id;
                    $_SESSION['user_nom'] = $user->nom;
                    $_SESSION['user_prenom'] = $user->prenom;
                    $_SESSION['user_email'] = $user->email;
                    $_SESSION['role'] = $user->role;
                    
                    // Redirection selon le rôle
                    if ($user->role == 'admin') {
                        $this->redirect('admin');
                    } elseif ($user->role == 'it') {
                        $this->redirect('event');
                    } else {
                        $this->redirect('product');
                    }
                } else {
                    // Message d'erreur
                    $data['errors']['login'] = 'Email ou mot de passe incorrect';
                    $this->view('auth/login', ['errors' => $data['errors'], 'data' => $data]);
                }
            } else {
                // Afficher le formulaire avec les erreurs
                $this->view('auth/login', ['errors' => $data['errors'], 'data' => $data]);
            }
        } else {
            // Afficher le formulaire de connexion
            $this->view('auth/login');
        }
    }
    
    public function logout() {
        // Détruire la session
        session_unset();
        session_destroy();
        
        // Redirection vers la page d'accueil
        $this->redirect('');
    }
    
    public function resetPassword() {
        // Implémentation de la réinitialisation du mot de passe
        $this->view('auth/reset_password');
    }
} 