-- Script de création de la base de données MY Boutique
-- À exécuter dans phpMyAdmin ou via un client MySQL

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS my_boutique;
USE my_boutique;

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    adresse TEXT NOT NULL,
    carte_bancaire VARCHAR(255),
    role ENUM('client', 'it', 'admin') NOT NULL DEFAULT 'client',
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des produits
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    prix DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    categorie VARCHAR(50) NOT NULL,
    image VARCHAR(255) NOT NULL,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des commandes
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10, 2) NOT NULL,
    statut ENUM('en cours', 'expédiée', 'livrée', 'annulée') NOT NULL DEFAULT 'en cours',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table des éléments de commande
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantite INT NOT NULL,
    prix DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Table des événements
CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    titre VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    date DATE NOT NULL,
    image VARCHAR(255) NOT NULL,
    valide BOOLEAN NOT NULL DEFAULT FALSE,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Table des commentaires sur les produits
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    contenu TEXT NOT NULL,
    note INT NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Création d'un utilisateur administrateur
INSERT INTO users (nom, prenom, email, mot_de_passe, adresse, role) VALUES 
('Admin', 'System', 'admin@myboutique.com', '$2y$10$yvZhYXQVrZxNM1HkSvyDQeusTMXZCrA4N6gApxI5IqnKP0s4Wn.hO', 'Adresse administration', 'admin');

-- Création d'un utilisateur IT/Commercial
INSERT INTO users (nom, prenom, email, mot_de_passe, adresse, role) VALUES 
('Commercial', 'IT', 'it@myboutique.com', '$2y$10$yvZhYXQVrZxNM1HkSvyDQeusTMXZCrA4N6gApxI5IqnKP0s4Wn.hO', 'Adresse commerciale', 'it');

-- Insertion de quelques produits de démo
INSERT INTO products (nom, description, prix, stock, categorie, image) VALUES
('T-shirt Classic', 'T-shirt classique en coton bio', 19.99, 50, 'Vêtements', '/MY-boutique/public/assets/uploads/products/tshirt.jpg'),
('Jean Slim', 'Jean coupe slim en denim stretch', 49.99, 30, 'Vêtements', '/MY-boutique/public/assets/uploads/products/jean.jpg'),
('Baskets Urbaines', 'Baskets confortables pour un style urbain', 79.99, 25, 'Chaussures', '/MY-boutique/public/assets/uploads/products/baskets.jpg'),
('Sac à main Élégant', 'Sac à main élégant en cuir véritable', 99.99, 15, 'Accessoires', '/MY-boutique/public/assets/uploads/products/sac.jpg'),
('Montre Classique', 'Montre avec bracelet en cuir et cadran minimaliste', 129.99, 10, 'Accessoires', '/MY-boutique/public/assets/uploads/products/montre.jpg');

-- Insertion de quelques événements de démo
INSERT INTO events (user_id, titre, description, date, image, valide) VALUES
(2, 'Soldes d''été', 'Profitez de nos soldes d''été avec jusqu''à 70% de réduction sur une sélection d''articles', '2023-07-15', '/MY-boutique/public/assets/uploads/events/soldes.jpg', 1),
(2, 'Nouvelle collection automne', 'Découvrez notre nouvelle collection automne-hiver', '2023-09-10', '/MY-boutique/public/assets/uploads/events/collection.jpg', 1);

-- Note: le mot de passe hashé est "password123" pour les comptes admin et IT 