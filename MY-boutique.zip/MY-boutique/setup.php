<?php
/**
 * Script d'installation pour MY Boutique
 * Ce script crée les dossiers nécessaires et vérifie la configuration
 */

echo "===========================================\n";
echo "Installation de MY Boutique\n";
echo "===========================================\n\n";

// Chemins des dossiers à créer
$directories = [
    'public/assets/uploads',
    'public/assets/uploads/products',
    'public/assets/uploads/events'
];

// Création des dossiers
echo "Création des dossiers d'upload...\n";
foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        if (mkdir($dir, 0777, true)) {
            echo "✅ Dossier créé: $dir\n";
        } else {
            echo "❌ Échec de la création du dossier: $dir\n";
        }
    } else {
        echo "✓ Le dossier existe déjà: $dir\n";
    }
}

// Vérification des permissions
echo "\nVérification des permissions...\n";
foreach ($directories as $dir) {
    if (is_writable($dir)) {
        echo "✅ Permissions OK pour: $dir\n";
    } else {
        echo "❌ Le dossier n'est pas accessible en écriture: $dir\n";
        echo "   Veuillez définir les permissions appropriées (chmod 777 $dir)\n";
    }
}

// Vérification de la configuration de la base de données
echo "\nVérification de la configuration de la base de données...\n";
$dbConfigFile = 'config/database.php';
if (file_exists($dbConfigFile)) {
    echo "✅ Fichier de configuration de la base de données trouvé\n";
    echo "   N'oubliez pas de configurer vos paramètres de connexion dans ce fichier si nécessaire.\n";
} else {
    echo "❌ Fichier de configuration de la base de données non trouvé: $dbConfigFile\n";
}

// Vérification des fichiers .htaccess
echo "\nVérification des fichiers .htaccess...\n";
$htaccessFiles = [
    '.htaccess',
    'public/.htaccess'
];
foreach ($htaccessFiles as $file) {
    if (file_exists($file)) {
        echo "✅ Fichier .htaccess trouvé: $file\n";
    } else {
        echo "❌ Fichier .htaccess manquant: $file\n";
    }
}

echo "\n===========================================\n";
echo "Pour finaliser l'installation:\n";
echo "1. Importez le fichier database.sql dans votre base de données MySQL\n";
echo "2. Vérifiez la configuration dans config/database.php\n";
echo "3. Accédez à l'application via: http://localhost/MY-boutique/\n";
echo "===========================================\n";
echo "Comptes de démonstration:\n";
echo "Admin: admin@myboutique.com / password123\n";
echo "IT/Commercial: it@myboutique.com / password123\n";
echo "===========================================\n"; 