<?php
echo "<h1>Test de MY-boutique</h1>";
echo "<p>Si vous pouvez voir cette page, le serveur web fonctionne correctement.</p>";
echo "<p>Chemin actuel : " . __DIR__ . "</p>";
echo "<hr>";
echo "<h2>Vérification des fichiers principaux :</h2>";
echo "<ul>";
$files = [
    '../core/App.php',
    '../core/Controller.php',
    '../core/Model.php',
    '../config/database.php',
    '../app/controllers/HomeController.php',
    '.htaccess'
];
foreach ($files as $file) {
    echo "<li>" . $file . " : " . (file_exists($file) ? "✓" : "✗") . "</li>";
}
echo "</ul>";
?> 