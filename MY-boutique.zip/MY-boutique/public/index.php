<?php
require_once '../config/database.php';
require_once '../core/App.php';
require_once '../core/Controller.php';
require_once '../core/Model.php';

// Lancer l'application
$app = new App(); 