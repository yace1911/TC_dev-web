<?php
// Rediriger toutes les requêtes vers le dossier public
header('Location: public/');
exit;
?> 